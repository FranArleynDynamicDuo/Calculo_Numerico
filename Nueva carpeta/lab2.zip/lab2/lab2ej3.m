%1)Construccion del sistema solicitado, con n=16
disp('Ahora se resolver� el sistema asociado a la matriz de Hadamard n=16')
disp('Presione una tecla para continuar')
pause
a=hadamard(16)
b=a*ones(16,1)
disp('Presione una tecla para continuar')
pause

%2) Es la matriz invertible?
if det(a)~=0
    disp('La matriz del sistema es invertible: su determinante no es 0')
else disp('La matriz del sistema no es invertible: su determinante es 0')
end
disp('Presione una tecla para continuar')
pause

%Como el determinante es distinto de cero, la matriz es invertible

%3)N�mero de condici�n de la matriz a
condicion_norma_1=cond(a,2)
condicion_norma_inf=cond(a,inf)
disp('Presione una tecla para continuar')
pause

%Como el n�mero de condici�n en norma 2 es uno, podemos concluir que el
%sistema de ecuaciones que origina dicha matriz est� bien condicionado, por
%lo tanto el problema plantea mayor facilidad a ser resuelto usando m�todos
%num�ricos

%4) Hallar la soluci�n del sistema ax=b, usando Gauss sin pivoteo
% Gracias a los c�lculos manuales, sabemos que la soluci�n real del sistema
% es un vector de unos
disp('A continuaci�n los resultados resolviendo el sistema sin pivoteo')
disp('Resultados con tolerancia 1e-12')
disp('Presione una tecla para continuar')
pause
solreal=ones(16,1)
sol=elimgauss(a,b,1e-12)
error_sin_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

disp('Resultados con tolerancia 1e-16')
disp('Presione una tecla para continuar')
pause
solreal=ones(16,1)
sol=elimgauss(a,b,1e-16)
error_sin_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

%5) Hallar la soluci�n del sistema ax=b, usando Gauss con pivoteo
% Gracias a los c�lculos manuales, sabemos que la soluci�n real del sistema
% es un vector de unos
disp('A continuaci�n los resultados resolviendo el sistema con pivoteo')
disp('Resultados con tolerancia 1e-12')
disp('Presione una tecla para continuar')
pause
solreal=ones(16,1)
sol=elimgausspiv(a,b,1e-12)
error_con_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

disp('Resultados con tolerancia 1e-16')
disp('Presione una tecla para continuar')
pause
solreal=ones(16,1)
sol=elimgausspiv(a,b,1e-16)
error_con_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

%6) Ya que la matriz est� bien condicionada, los resultados se han
%verificado utilizando dos aproximaciones distintas (Gauss con y sin
%pivoteo) y ambos resultados concuerdan entre s� y con el valor real, puede
%concluirse que la soluci�n al sistema es confiable. El cambio en el valor
%de tolerancia no afect� las pruebas

%7) Resoluci�n del sistema con una matriz de Hadamard de tamano 20x20

disp('Ahora se resolver� el sistema asociado a la matriz de Hadamard n=20')
disp('Para observar la falla, se ha saltado el error en una funci�n nueva')
disp('Presione una tecla para continuar')
pause
a=hadamard(20)
b=a*ones(20,1)
disp('Presione una tecla para continuar')
pause

condicion_norma_1=cond(a,2)
condicion_norma_inf=cond(a,inf)
disp('Presione una tecla para continuar')
pause

% Gracias a los c�lculos manuales, sabemos que la soluci�n real del sistema
% es un vector de unos
solreal=ones(20,1)
disp('Presione una tecla para continuar')
pause

disp('A continuaci�n los resultados resolviendo el sistema sin pivoteo')
disp('Resultados con tolerancia 1e-12')
disp('Presione una tecla para continuar')
pause
sol=elimgauss2(a,b,1e-12)
error_sin_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

disp('Resultados con tolerancia 1e-16')
disp('Presione una tecla para continuar')
pause
sol=elimgauss2(a,b,1e-16)
error_sin_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

disp('A continuaci�n los resultados resolviendo el sistema con pivoteo')
disp('Resultados con tolerancia 1e-12')
disp('Presione una tecla para continuar')
pause
sol=elimgausspiv2(a,b,1e-12)
error_con_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

disp('Resultados con tolerancia 1e-16')
disp('Presione una tecla para continuar')
pause
sol=elimgausspiv2(a,b,1e-16)
error_con_pivote=norm((solreal-sol),inf)
disp('Presione una tecla para continuar')
pause

% Ahora con una matriz 20x20 se observan detalles importantes: al utilizar
% Gauss sin pivoteo, y con una tolerancia de 1e-12 se observa un pivote
% nulo en la fila 11. De aqu� en adelante, empiezan a ocurrir errores de
% cancelaci�n en cifras significativas en las operaciones de fila, los
% cuales se maximizan a trav�s de la divisi�n entre un n�mero muy pequeno.
% Esta propagaci�n de errores nos conduce a un error total de 0.91
% aproximadamente, lo cual es inaceptable para soluciones del orden de 1.
% Cuando se disminuye la tolerancia se evita la detecci�n del pivote nulo,
% pero no se evita la propagaci�n de errores
%
% En cambio, cuando se utiliza el m�todo de Gauss con pivoteo, la selecci�n
% de un mejor pivote contribuye a que el error sea solamente cuatro veces
% el epsilon de la m�quina (aproximadamente, calculado con norma infinito).
% A pesar de esto, se obtiene un pivote nulo en la fila 18. se puede decir
% que la detecci�n de un pivote nulo en la fila 18 nos alerta de posibles
% errores propagados a partir de este punto, de igual forma que en el
% ejercicio anterior (cancelaci�n y luego incremento del error por dividir
% entre un numero muy pequeno), pero como esto ocurre cerca del final del
% procedimiento, el error no es significativo.
%
% Se concluye entonces que la elecci�n de un mejor pivote contribuye
% significativamente en la disminuci�n de la propagaci�n de errores, y es
% un m�todo num�rico que, usado adecuadamente, puede ayudar a la resoluci�n
% de problemas matriciales
function [fid] = grafn(qwe,asd)
% Graficadora de expresiones (1-|x|^z)^(1/z)
% Descripci�n:
% Esta funci�n es una demostraci�n de las normas vectoriales, obteniendo
% una representaci�n de un c�rculo unitario utilizando las normas que se
% colocan como par�metros. Obtiene una gr�fica para las expresiones 
% (1-|x|^z)^(1/z) y -(1-|x|^z)^(1/z) entre -1 y 1. 
%------------------------------------------------------------------------
% Par�metros:
% El primer par�metro indica el intervalo de 
% crecimiento de los puntos de la gr�fica, y el segundo el conjunto de
% valores p que se usar�n en las normas vectoriales. De esta forma se
% puede apreciar el cambio de la gr�fica a medida que cambia la norma
% vectorial.
%------------------------------------------------------------------------
% Ejemplo:
% grafn(0.01,[2,3,4]) devuelve las gr�ficas de (1-|x|^2)^(1/2), 
% (1-|x|^3)^(1/3) y (1-|x|^4)^(1/4) en un solo cuadro de ploteo
%------------------------------------------------------------------------

close all
fid=figure
hold on
for z = asd
x = -1 : qwe : 1 ;
cv = power( 1 - power( abs( x ) , z ) , 1 / z ) ;
bn = -power( 1 - power( abs( x ) , z ) , 1 / z ) ;
plot( x , cv )
plot( x , bn )
end
return;
function [ x ] = elimgausspiv( A , b , tol )
% Documentacion de la funcion
% Variables de entrada :
% A
% b
% Variables de salida ;
% x
% tol : Tolerancia para valores nulos
% Gustavo El Khoury
% gustavo@ldc.usb.ve
% Verficaciones iniciales
[ m , n ] = size( A ) ;
if m ~= n
error('Matriz no es cuadrada')
end
[ m , l ] = size( b ) ;
if ( m ~= n || l ~= 1 )
error('Sistema no consistente')
end
x = zeros( n , 1 ) ;
A = [ A , b ] ; % Matriz aumentada
% Eliminacion gaussiana
for i = 1 : n - 1
if abs( A( i , i ) ) < tol
disp( ['Pivote nulo en fila ',num2str(i) ] )
end
% Reordenamiento de filas por pivoteo
[val,pos]=max(abs(A(i:n,i)));
pos=pos+i-1;
if pos ~= i 
temp=A(pos,:);
A(pos,:)=A(i,:);
A(i,:)=temp;
end
% Eliminacion en las filas debajo de la diagonal i
for j = i + 1 : n
mult = A( j , i ) / A( i , i ) ;
A( j , i ) = 0 ;
A( j , i + 1 : n + 1 ) = A( j , i + 1 : n + 1 ) ...
- mult * A( i , i + 1 : n + 1 ) ;
end
end
if abs( A( n , n ) ) < tol
disp('Pivote nulo')
end
% Vector de lado derecho luego de la eliminacion gaussiana
b = A( : , n + 1 ) ;
% Sustitucion regresiva
x( n , 1 ) = b( n ) / A( n , n ) ;
for i = n - 1 : - 1 : 1
x( i , 1 ) = ( b( i ) - ...
A( i , i + 1 : n ) * x( i + 1 : n , 1 ) ) / A( i , i ) ;
end
end
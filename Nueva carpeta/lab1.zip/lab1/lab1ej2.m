x=-3:.01:3;
f1=@(x)(1-cos(x))./(x.^2);
plot(x,f1(x),'-r')
title('Aproximacion 1')
grid
disp('La funcion 1 evaluada en 1.2 x 10^-8 resulta')
eval1=f1(1.2e-5);
disp(eval1)
question=input('Presione una tecla para continuar.');
disp('')

f2=@(x)(0.5*((sin(x/2)./(x/2)).^2));
figure()
plot(x,f2(x),'-b')
title('Aproximacion 2')
grid
disp('La funcion 2 evaluada en 1.2 x 10^-8 resulta')
eval2=f2(1.2e-5);
disp(eval2)

% En la primera aproximacion se comete un error de cancelacion, pues en
% valores cercanos a 0, el coseno se aproxima muchisimo a 1. Ademas, en el
% denominador se encuentra una cantidad muy pequeña elevada luego al
% cuadrado. Dividir el numero con errores entre una cantidad muy pequeña
% amplifica el error, ocasionando un error de division. En la segunda
% aproximacion se elimina el error de cancelacion aplicando propiedades
% notables del seno y coseno para eliminar la resta. Al mismo tiempo, el
% error de division se eliminia pues no hay un error que se amplifique.
x=8.3*ones(1,26);
z=[0:25];
altern=(-1).^z;
fact=factorial(z);
terms=altern.*((x.^z)./fact);
aprox=sum(terms)

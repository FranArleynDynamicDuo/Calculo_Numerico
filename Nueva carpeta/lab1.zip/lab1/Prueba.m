x=input('Variable: ')
disp(sin(x))
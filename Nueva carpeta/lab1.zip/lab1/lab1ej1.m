s1=0;
N=100;
x=8.3;
for i=0:N
    s1=s1+(((-1)^i)*((x)^i))/factorial(i);
end
disp('La primera aproximacion resulta ')
disp(s1)
disp('El error en esta aproximacion es')
disp(abs(exp(-8.3)-s1))

s2=0;
x=-8.3;
for i=0:N
    s2=s2+((x)^i)/factorial(i);
end
disp('La segunda aproximacion resulta ')
disp(s2)
disp('El error en esta aproximacion es')
disp(abs(exp(-8.3)-s2))

% La primera aproximacion emplea un termino alternante que resulta en
% restas a lo largo de la aproximacion por Taylor. A medida que los valores
% decrecen, empiezan a cometerse errores de cancelacion, y esto disminuye
% la estabilidad de la formula. Deben aumentarse la cantidad de terminos
% para que la formula se aproxime mas al valor real. Por el contrario, con
% la segunda formula no se hacen restas, la formula se vuelve mas estable y
% requiere menos terminos. Se observa que no importa cuanto aumentemos la
% cantidad de terminos, el error absoluto calculado nunca es inferior al
% valor epsilon de la maquina, que determina el numero mas pequeño con el
% que puede trabajar el procesador, a pesar de que la memoria pueda
% almacenar numeros mas pequeños.


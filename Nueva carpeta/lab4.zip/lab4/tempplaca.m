function[x]=tempplaca(tempsup,tempinf,tempizq,tempder);
% Funci�n: Temperatura de los nodos de las placas
% Ejercicio propuesto para el laboratorio 4 de C03211 de Abr-Jul2012
% Par�metros: Temperaturas del borde superior, inferior, izquierdo y derecho
% Autor: Gustavo El Khoury
% Contacto: gustavo@ldc.usb.ve
a=[4,-1,-1,0,0,0,0,0;-1,4,0,-1,0,0,0,0;-1,0,4,-1,-1,0,0,0;0,-1,-1,4,0,-1,0,0;0,0,-1,0,4,-1,-1,0;0,0,0,-1,-1,4,0,-1;0,0,0,0,-1,0,4,-1;0,0,0,0,0,-1,-1,4;];
b=[tempsup+tempizq;tempinf+tempizq;tempsup;tempinf;tempsup;tempinf;tempsup+tempder;tempinf+tempder];
l=cholesky(a);
u=l';
y=sustprog(l,b);
x=sustregr(u,y);
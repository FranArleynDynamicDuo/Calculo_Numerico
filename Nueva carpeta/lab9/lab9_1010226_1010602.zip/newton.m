function coef = newton( x , y )
% NEWTON Interpolacion de Newton
n = length( x ) ;
coef = y ;
for i = 1 : ( n - 1 )
    coef( i + 1 : n ) = ( coef( i + 1 : n ) - coef( i : n - 1 ) ) ./ ...
     ( x( i + 1 : 1 : n ) - x( 1 : 1 : n - i ) ) ;
end

end


f=@(x)1./(1.+exp(-x));
df=@(x)exp(x)./((1.+exp(x)).*(1.+exp(x)));
xx=linspace(-6,6,1000)';
aviobj=avifile('lab8.avi');
fig=figure;

for i=2:10
    x_newton=linspace(-6,6,2*i)';
    y_newton=f(x_newton);
    pol_newton=newton(x_newton,y_newton);
    eval_newton=evalpol(x_newton,pol_newton,xx);
    x_hermit=linspace(-6,6,i)';
    y_hermit=f(x_hermit);
    x_hermit_final=zeros(2*i,1);
    for j=2:2:2*i
        x_hermit_final(j-1,1)=x_hermit(j/2,1);
        x_hermit_final(j,1)=x_hermit(j/2,1);
    end
    dy_hermit=df(x_hermit);
    pol_hermit=hermite(x_hermit,y_hermit,dy_hermit);
    eval_hermit=evalpol(x_hermit_final,pol_hermit ,xx);
    plot(xx,f(xx),'-k',x_newton,y_newton,'*b',xx,eval_newton,'-b',x_hermit,y_hermit,'*r',xx,eval_hermit,'-r')
    title(['Gráfica para n=',num2str(i)])
    legend('Gráfica Esperada','Puntos de Newton','Aproximación por Newton','Puntos de Hermit','Aproximación por Hermit','Location','SouthEast')
    grid
    F = getframe(fig);
    aviobj = addframe(aviobj,F)
    F = getframe(fig);
    aviobj = addframe(aviobj,F)
    F = getframe(fig);
    aviobj = addframe(aviobj,F)
    F = getframe(fig);
    aviobj = addframe(aviobj,F)
    F = getframe(fig);
    aviobj = addframe(aviobj,F)
    F = getframe(fig);
    aviobj = addframe(aviobj,F)
    pause(0.2)
   
end
close(fig)
aviobj = close(aviobj)
    
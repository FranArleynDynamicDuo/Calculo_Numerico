function coef = hermite( x , y , dy )
% HERMITE Interpolacion de Hermite
m = length( x ) ; 
t = zeros( 2 * m , 1 ) ;
coef = zeros( 2 * m , 1 ) ;
coef( 1 ) = y( 1 ) ;
coef( 3 : 2 : 2 * m - 1 ) = ( y( 2 : m ) - y( 1 : m - 1 ) ) ./ ...
     ( x( 2 : m ) - x( 1 : m - 1 ) ) ;
for i = 1 : m
    t( ( 2 * i ) - 1 ) = x( i ) ;
    t( 2 * i ) = x( i ) ;
    coef( 2 * i ) = dy( i ) ;
end
n = 2 * m ;
for i = 2 : ( n - 1 ) 
    coef( i + 1 : n ) = ( coef( i + 1 : n ) - coef( i : n - 1 ) ) ./ ...
     ( t( i + 1 : 1 : n ) - t( 1 : 1 : n - i ) ) ;
end
    
end


function yy = evalpol( x , coef , xx )
% EVALPOL Evaluacion de polinomios de Newton y hermite
n = length( coef ) ;
l = length( xx ) ;
yy = coef( 1 ) * ones( l , 1 ) ;
p = ones( l , 1 ) ;
for k = 2 : n
     p = p .* ( xx - x( k - 1 ) ) ;
     yy = yy + coef( k ) * p ;
end
a1=[1,0.100000000000000,0.200000000000000;0.400000000000000,1,-0.200000000000000;-0.300000000000000,0.010000000000000,1]
b1=[1;1;1]
x0=[0;0;0]
tic
  disp('Solución al primer sistema usando Jacobi')
  [x11,H11]=jacobi(a1,b1,x0,100,1e-12);
  x11
tiempo_jacobi_s1=toc
disp('El radio espectral de la matriz der iteraciones es')
max(abs(eig(H11)))
disp('El residual es')
norm((b1-(a1*x11)),inf)
tic
  disp('Solución al primer sistema usando Gauss-Seidel')
  [x12,H12]=gauss_seidel(a1,b1,x0,100,1e-12);
  x12
tiempo_gauss_seidel_s1=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H12)))
disp('El residual es')
norm((b1-(a1*x12)),inf)
tic
  disp('Solución al primer sistema usando SOR')
  [x13,H13]=sor(a1,b1,x0,1.1,100,1e-12);
  x13
tiempo_sor_s1=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H13)))
disp('El residual es')
norm((b1-(a1*x13)),inf)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a2=[-3,1,2;-1,3,1;-4.8,-1,3]
b2=[9;7;6]
tic
  disp('Solución al segundo sistema usando Jacobi')
  [x21,H21]=jacobi(a2,b2,x0,100,1e-12);
  x21
tiempo_jacobi_s2=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H21)))
disp('El residual es')
norm((b2-(a2*x21)),inf)
tic
  disp('Solución al segundo sistema usando Gauss-Seidel')
  [x22,H22]=gauss_seidel(a2,b2,x0,100,1e-12);
  x22
tiempo_gauss_seidel_s2=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H22)))
disp('El residual es')
norm((b2-(a2*x22)),inf)
tic
  disp('Solución al segundo sistema usando SOR')
  [x23,H23]=sor(a2,b2,x0,1.1,100,1e-12);
  x23
tiempo_sor_s2=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H23)))
disp('El residual es')
norm((b2-(a2*x23)),inf)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a3=[-3,-2,0,-1;-4,-3,-4,-1;2,-3,4,-3;0,0,-3,3]
b3=[1;-1;1;-1]
x0=zeros(4,1);
tic
  disp('Solución al tercer sistema usando Jacobi')
  [x31,H31]=jacobi(a3,b3,x0,100,1e-12);
  x31
tiempo_jacobi_s3=toc
disp('El radio espectral de la matriz der iteraciones es')
max(abs(eig(H31)))
disp('El residual es')
norm((b3-(a3*x31)),inf)
tic
  disp('Solución al tercer sistema usando Gauss-Seidel')
  [x32,H32]=gauss_seidel(a3,b3,x0,100,1e-12);
  x32
tiempo_gauss_seidel_s3=toc
disp('El radio espectral de la matriz der iteraciones es')
max(abs(eig(H32)))
disp('El residual es')
norm((b3-(a3*x32)),inf)
tic
  disp('Solución al tercer sistema usando SOR')
  [x33,H33]=sor(a3,b3,x0,1.1,100,1e-12);
  x33
tiempo_sor_s3=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H33)))
disp('El residual es')
norm((b3-(a3*x33)),inf)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a4=[-4,-1,0,-1,0,0;-1,4,-1,0,-1,0;0,-1,4,0,0,-1;-1,0,0,4,-1,0;0,-1,0,-1,4,-6;0,0,-1,0,-1,4]
b4=[0;5;0;6;-2;6]
x0=zeros(6,1);
tic
  disp('Solución al cuarto sistema usando Jacobi')
  [x41,H41]=jacobi(a4,b4,x0,100,1e-12);
  x41
tiempo_jacobi_s4=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H41)))
disp('El residual es')
norm((b4-(a4*x41)),inf)
tic
  disp('Solución al cuarto sistema usando Gauss-Seidel')
  [x42,H42]=gauss_seidel(a4,b4,x0,100,1e-12);
  x42
tiempo_gauss_seidel_s4=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H42)))
disp('El residual es')
norm((b4-(a4*x42)),inf)
tic
  disp('Solución al cuarto sistema usando SOR')
  [x43,H43]=sor(a4,b4,x0,1.1,100,1e-12);
  x43
tiempo_sor_s4=toc
disp('El radio espectral de la matriz der iteraciones es');
max(abs(eig(H43)))
disp('El residual es')
norm((b4-(a4*x43)),inf)
function[x,H]=gauss_seidel(A,b,x0,n_iter,tol);
[m,n]=size(A);
[p,q]=size(b);
if m~=n || m~=p 
    error('Sistema no consistente')
end
d=zeros(n,n);
e=zeros(n,n);
f=zeros(n,n);
for i=1:n
    d(i,i)=A(i,i);
    for j=1:n
        if i<j
            e(i,j)=0;
            f(i,j)=-A(i,j);
        elseif i==j
                e(i,j)=0;
                f(i,j)=0;
        elseif i>j
            f(i,j)=0;
            e(i,j)=-A(i,j);
        end
    end
end;
x=(d-e)\(f*x0+b);
H=inv(d-e)*f;
for k=1:n_iter
    x_ant=x;
    x=(d-e)\(f*x+b);
    if norm(x-x_ant,inf) < tol
        return;
    end
end;
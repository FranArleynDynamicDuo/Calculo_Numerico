function y = funcion1(x)

    y = ((1 - cos(x)) ./ x.^2); 

end
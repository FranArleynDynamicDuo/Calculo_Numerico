function y = funcion2(x)

    y = (1/2) * ((sin(x./2)./(x./2)).^2); 

end